
import React, { useState, useRef } from 'react';
import { X, Upload, FileText, CheckCircle, Loader2, Sparkles, BrainCircuit, FileAudio, ImageIcon } from 'lucide-react';
import { SuccessCase, Role, Industry } from '../types';
import { generateCaseDataFromAI, generateCaseImage } from '../geminiService';

interface UploadPortalProps {
  onClose: () => void;
  onAdd: (c: SuccessCase) => void;
}

const UploadPortal: React.FC<UploadPortalProps> = ({ onClose, onAdd }) => {
  const [mode, setMode] = useState<'manual' | 'ai'>('ai');
  const [step, setStep] = useState(1);
  const [files, setFiles] = useState<File[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [genStatus, setGenStatus] = useState('');
  
  const [formData, setFormData] = useState({
    title: '',
    client: '',
    role: 'SoftwareDevelopment' as Role,
    industry: 'Technology' as Industry,
    summary: '',
    results: ''
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
      reader.readAsDataURL(blob);
    });
  };

  const handleAiGenerate = async () => {
    if (files.length === 0) return;
    
    setIsGenerating(true);
    setGenStatus('正在分析多模態數據資料...');
    
    try {
      const parts: any[] = [];
      for (const f of files) {
        const base64 = await blobToBase64(f);
        parts.push({
          inlineData: {
            data: base64,
            mimeType: f.type || 'application/octet-stream'
          }
        });
      }
      parts.push({ text: "請根據以上資料生成一個專業的企業成功案例。包含標題、客戶、分類、詳細內容與量化商業影響。年份設為 2026。" });

      const aiData = await generateCaseDataFromAI(parts);
      
      setGenStatus('正在根據案例內容自動產製頂級視覺封面...');
      const imageUrl = await generateCaseImage(aiData.imagePrompt);

      const newCase: SuccessCase = {
        id: Math.random().toString(36).substr(2, 9),
        title: aiData.title,
        client: aiData.client,
        role: aiData.role as Role,
        industry: aiData.industry as Industry,
        summary: aiData.summary,
        detailedContent: aiData.detailedContent,
        imageUrl: imageUrl,
        tags: [aiData.role, 'AI-Generated', 'Strategic'],
        date: '2026/' + new Date().toLocaleDateString().split('/')[1] + '/' + new Date().toLocaleDateString().split('/')[2],
        results: aiData.results,
        nps: 9.8,
        businessImpact: aiData.impacts
      };

      setGenStatus('發佈完成！');
      setTimeout(() => {
        setIsGenerating(false);
        setStep(3);
        setTimeout(() => onAdd(newCase), 1500);
      }, 1000);

    } catch (error) {
      console.error(error);
      setGenStatus('生成失敗，請檢查資料格式後重試');
      setIsGenerating(false);
    }
  };

  const handleManualUpload = () => {
    if (!formData.title) return;
    const newCase: SuccessCase = {
      id: Math.random().toString(36).substr(2, 9),
      title: formData.title,
      client: formData.client || '企業戰略夥伴',
      role: formData.role,
      industry: formData.industry,
      summary: formData.summary || '手動發佈的專案摘要。',
      detailedContent: `本專案聚焦於 ${formData.role} 領域的深度轉型與賦能。`,
      imageUrl: `https://images.unsplash.com/photo-1639322537228-f710d846310a?auto=format&fit=crop&q=80&w=800`,
      tags: [formData.role, 'Verified'],
      date: '2026/01/01',
      results: formData.results || '顯著提升關鍵營運指標',
      nps: 9.5
    };
    setStep(3);
    setTimeout(() => onAdd(newCase), 1500);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-slate-950/85 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-3xl rounded-[50px] overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.3)] flex flex-col relative border border-white/20">
        
        {isGenerating && (
          <div className="absolute inset-0 z-50 bg-white/95 backdrop-blur-md flex flex-col items-center justify-center space-y-8">
            <div className="relative">
              <div className="w-28 h-28 border-[6px] border-purple-100 border-t-[#7c3aed] rounded-full animate-spin" />
              <BrainCircuit className="absolute inset-0 m-auto w-12 h-12 text-[#7c3aed] animate-pulse" />
            </div>
            <div className="text-center">
              <h3 className="text-2xl font-black text-slate-900">AI 戰略顧問深度分析中</h3>
              <p className="text-slate-400 font-bold text-base mt-3">{genStatus}</p>
            </div>
          </div>
        )}

        <div className="p-10 border-b border-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-purple-100 rounded-[24px] flex items-center justify-center shadow-inner">
              <BrainCircuit className="w-9 h-9 text-[#7c3aed]" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">案例發佈數位中心</h2>
              <div className="flex gap-3 mt-2">
                <button onClick={() => setMode('ai')} className={`text-xs font-black px-5 py-1.5 rounded-full uppercase tracking-widest transition-all ${mode === 'ai' ? 'bg-slate-900 text-white shadow-lg' : 'bg-slate-50 text-slate-400 hover:bg-slate-100'}`}>AI 自動生成</button>
                <button onClick={() => setMode('manual')} className={`text-xs font-black px-5 py-1.5 rounded-full uppercase tracking-widest transition-all ${mode === 'manual' ? 'bg-slate-900 text-white shadow-lg' : 'bg-slate-50 text-slate-400 hover:bg-slate-100'}`}>手動發佈</button>
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-4 hover:bg-slate-50 rounded-full transition-colors"><X className="w-8 h-8 text-slate-300" /></button>
        </div>

        <div className="p-12">
          {step === 1 && (
            <div className="space-y-10">
              {mode === 'ai' ? (
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-4 border-dashed border-slate-100 rounded-[45px] p-20 flex flex-col items-center justify-center hover:border-purple-200 hover:bg-purple-50/20 transition-all cursor-pointer group relative overflow-hidden shadow-inner"
                >
                  <input type="file" className="hidden" ref={fileInputRef} onChange={handleFileChange} multiple accept="image/*,audio/*,video/*,.pdf,.doc,.docx,.ppt,.pptx" />
                  <div className="flex gap-6 mb-8">
                    <div className="w-16 h-16 bg-white rounded-2xl shadow-md flex items-center justify-center text-blue-500 group-hover:scale-110 transition-transform"><ImageIcon className="w-8 h-8" /></div>
                    <div className="w-16 h-16 bg-white rounded-2xl shadow-md flex items-center justify-center text-[#7c3aed] group-hover:scale-110 transition-transform [animation-delay:0.1s]"><FileAudio className="w-8 h-8" /></div>
                    <div className="w-16 h-16 bg-white rounded-2xl shadow-md flex items-center justify-center text-amber-500 group-hover:scale-110 transition-transform [animation-delay:0.2s]"><FileText className="w-8 h-8" /></div>
                  </div>
                  <div className="text-center relative z-10">
                    <p className="text-xl font-black text-slate-900">{files.length > 0 ? `已選取 ${files.length} 個戰略文件檔案` : '拖放或點擊上傳原始案例資料'}</p>
                    <p className="text-base text-slate-400 font-bold mt-3">支援專案簡報、訪談錄音或系統截圖</p>
                  </div>
                  {files.length > 0 && (
                     <div className="mt-8 flex flex-wrap gap-3 justify-center">
                        {files.map((f, i) => <span key={i} className="px-4 py-2 bg-white border border-slate-100 rounded-xl text-xs font-black text-slate-600 truncate max-w-[150px] shadow-sm">{f.name}</span>)}
                     </div>
                  )}
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-8">
                  <div className="col-span-2">
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3">成功案例標題 *</label>
                    <input type="text" placeholder="輸入專案名稱..." className="w-full bg-slate-50 border border-slate-100 rounded-[24px] p-6 text-base font-bold outline-none focus:ring-4 focus:ring-purple-50 focus:bg-white transition-all shadow-sm" value={formData.title} onChange={(e) => setFormData({...formData, title: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3">解決方案分類</label>
                    <select className="w-full bg-slate-50 border border-slate-100 rounded-[24px] p-6 text-base font-bold outline-none focus:ring-4 focus:ring-purple-50 transition-all shadow-sm" value={formData.role} onChange={(e) => setFormData({...formData, role: e.target.value as Role})}>
                      <option value="SoftwareDevelopment">軟體開發</option>
                      <option value="CustomerExperience">客戶體驗</option>
                      <option value="OperationsEfficiency">營運效率</option>
                      <option value="DataInsight">數據洞察</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3">目標產業</label>
                    <select className="w-full bg-slate-50 border border-slate-100 rounded-[24px] p-6 text-base font-bold outline-none focus:ring-4 focus:ring-purple-50 transition-all shadow-sm" value={formData.industry} onChange={(e) => setFormData({...formData, industry: e.target.value as Industry})}>
                      <option value="Finance">金融保險</option>
                      <option value="Healthcare">醫療保健</option>
                      <option value="Retail">零售消費</option>
                      <option value="Technology">科技通訊</option>
                    </select>
                  </div>
                </div>
              )}

              <button 
                onClick={mode === 'ai' ? handleAiGenerate : handleManualUpload}
                disabled={(mode === 'ai' && files.length === 0) || (mode === 'manual' && !formData.title)}
                className="w-full py-8 bg-slate-900 text-white rounded-[30px] font-black text-xl shadow-[0_20px_50px_rgba(0,0,0,0.2)] flex items-center justify-center gap-4 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 disabled:scale-100"
              >
                {mode === 'ai' ? <><Sparkles className="w-7 h-7 text-[#7c3aed]" /> 執行 AI 深度分析與數位製圖</> : '正式發佈至 2026 案例庫'}
              </button>
            </div>
          )}

          {step === 3 && (
            <div className="py-20 text-center animate-in zoom-in-95 duration-500">
              <div className="w-32 h-32 bg-green-50 text-green-500 rounded-[40px] flex items-center justify-center mx-auto mb-8 border-4 border-white shadow-2xl">
                <CheckCircle className="w-16 h-16" />
              </div>
              <h3 className="text-3xl font-black text-slate-900 tracking-tight">成功發佈！</h3>
              <p className="text-slate-500 mt-4 font-bold px-12 text-lg leading-relaxed">
                AI 戰略顧問已自動提取專案價值、量化 ROI 並生成頂級視覺。實績已即時呈現於全局導航。
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UploadPortal;
