
import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, User, Loader2, ExternalLink, ClipboardList, Sparkles, BrainCircuit } from 'lucide-react';
import { ChatMessage, SuccessCase } from '../types';
import { askAiAboutCases } from '../geminiService';

interface AIChatProps {
  isOpen: boolean;
  onClose: () => void;
  cases: SuccessCase[];
  onSelectCase: (id: string) => void;
  onOpenConsultant: () => void;
}

const AIChat: React.FC<AIChatProps> = ({ isOpen, onClose, cases, onSelectCase, onOpenConsultant }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'assistant', content: '• 您好！我是您的企業 AI 案例導覽員\n• 您可以詢問關於各產業的轉型實績\n• 如果您有特定技術難題，建議啟動「AI 戰略診斷」獲取量化分析報告' }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async (overrideMsg?: string) => {
    const userMsg = overrideMsg || inputValue.trim();
    if (!userMsg || isLoading) return;

    setInputValue('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    const history = messages.map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));

    try {
      const response = await askAiAboutCases(userMsg, cases, history);
      setMessages(prev => [...prev, { role: 'assistant', content: response || '• 抱歉，我無法處理您的請求，請換個方式描述' }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'assistant', content: '• 系統目前連線不穩，請稍候重試' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const renderContent = (content: string) => {
    let text = content;
    const elements: React.ReactNode[] = [];
    const caseRegex = /\[案例: ([^\]]+)\]/g;
    let lastIndex = 0;
    let match;

    while ((match = caseRegex.exec(text)) !== null) {
      const id = match[1].trim();
      elements.push(text.substring(lastIndex, match.index));
      elements.push(
        <button
          key={match.index}
          onClick={() => onSelectCase(id)}
          className="inline-flex items-center gap-2 px-3 py-1 bg-purple-50 text-[#7c3aed] rounded-lg border border-purple-100 font-black text-xs mx-1 hover:bg-purple-100 transition-colors shadow-sm"
        >
          <ExternalLink className="w-3 h-3" />
          查看解方
        </button>
      );
      lastIndex = caseRegex.lastIndex;
    }
    elements.push(text.substring(lastIndex));

    return <div className="whitespace-pre-line leading-relaxed tracking-tight">{elements}</div>;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-full sm:w-[450px] bg-white shadow-3xl z-[150] flex flex-col animate-in slide-in-from-right duration-500 ease-out sm:border-l border-gray-100">
      <div className="p-6 bg-slate-900 text-white flex items-center justify-between shrink-0 shadow-xl relative z-10">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-[#7c3aed] rounded-2xl flex items-center justify-center shadow-lg">
            <Bot className="w-7 h-7 text-white" />
          </div>
          <div>
            <h3 className="font-black text-base tracking-tight">AI 成功案例智庫</h3>
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-[0.2em] block mt-0.5">STRATEGIC CASE ASSISTANT</span>
          </div>
        </div>
        <button onClick={onClose} className="p-3 hover:bg-white/10 rounded-full transition-colors"><X className="w-6 h-6" /></button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-8 bg-slate-50/40 no-scrollbar">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex gap-4 max-w-[90%] ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-md ${msg.role === 'user' ? 'bg-slate-800' : 'bg-white border border-purple-100'}`}>
                {msg.role === 'user' ? <User className="w-5 h-5 text-white" /> : <Sparkles className="w-5 h-5 text-[#7c3aed]" />}
              </div>
              <div className={`p-5 rounded-3xl text-sm font-bold shadow-sm leading-relaxed ${msg.role === 'user' ? 'bg-[#7c3aed] text-white rounded-tr-none' : 'bg-white text-slate-700 rounded-tl-none border border-slate-100'}`}>
                {renderContent(msg.content)}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="flex gap-4 items-center">
              <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center border border-purple-100 shadow-sm"><Loader2 className="w-5 h-5 text-[#7c3aed] animate-spin" /></div>
              <div className="p-4 bg-white rounded-2xl rounded-tl-none border border-slate-100 flex gap-1.5"><span className="w-1.5 h-1.5 bg-purple-300 rounded-full animate-bounce"></span><span className="w-1.5 h-1.5 bg-purple-300 rounded-full animate-bounce [animation-delay:0.2s]"></span><span className="w-1.5 h-1.5 bg-purple-300 rounded-full animate-bounce [animation-delay:0.4s]"></span></div>
            </div>
          </div>
        )}

        <div className="p-8 bg-gradient-to-br from-[#7c3aed]/10 to-white border-2 border-purple-100 rounded-[40px] space-y-5 shadow-inner">
          <div className="flex items-center gap-3 text-[#7c3aed] font-black text-xs uppercase tracking-widest">
            <BrainCircuit className="w-5 h-5" /> 啟動專屬企業解方
          </div>
          <p className="text-sm text-slate-500 font-bold leading-relaxed">
            如需針對您的業務痛點進行 ROI 量化評估，建議使用「3 分鐘 AI 顧問診斷」。
          </p>
          <button 
            onClick={() => { onClose(); onOpenConsultant(); }}
            className="w-full py-5 bg-slate-900 text-white rounded-[24px] text-sm font-black flex items-center justify-center gap-3 hover:bg-slate-800 transition-all shadow-2xl active:scale-95"
          >
            啟動 AI 顧問診斷
          </button>
        </div>
      </div>

      <div className="p-6 border-t bg-white pb-10">
        <div className="relative flex items-center">
          <input 
            type="text" 
            placeholder="請輸入您的問題，如「金融業成功案例」..."
            className="w-full bg-slate-50 border border-slate-100 rounded-[24px] py-5 pl-7 pr-16 text-sm font-bold focus:ring-4 focus:ring-purple-50 focus:bg-white transition-all outline-none"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <button onClick={() => handleSend()} disabled={!inputValue.trim() || isLoading} className="absolute right-2.5 p-3.5 bg-[#7c3aed] text-white rounded-2xl hover:bg-purple-700 disabled:bg-gray-200 transition-all shadow-lg active:scale-90">
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default AIChat;
