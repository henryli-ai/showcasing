
import React, { useState } from 'react';
import { X, Loader2, CheckCircle2, TrendingUp, Mail, ClipboardCheck, ShieldAlert, Zap, BrainCircuit, Target, ArrowRight, Send, Crown, Sparkles } from 'lucide-react';
import { generateConsultantSolution } from '../geminiService';

interface AIConsultantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onContact: () => void;
}

const AIConsultantModal: React.FC<AIConsultantModalProps> = ({ isOpen, onClose, onContact }) => {
  const [painPoint, setPainPoint] = useState('');
  const [solution, setSolution] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState<'input' | 'result' | 'emailSent'>('input');
  const [isSendingEmail, setIsSendingEmail] = useState(false);

  const parseSolution = (text: string) => {
    const sections: Record<string, string> = {};
    const keys = ['SUMMARY', 'BEFORE', 'AFTER', 'ROI'];
    let currentKey = '';
    text.split('\n').forEach(line => {
      const foundKey = keys.find(k => line.includes(`[${k}]`));
      if (foundKey) {
        currentKey = foundKey;
      } else if (currentKey) {
        // 去除標籤前綴，只留內容
        const cleanLine = line.replace(/\[.*?\]\s*.*?(：|:)?\s*/, '').trim();
        if (cleanLine) {
          sections[currentKey] = (sections[currentKey] || '') + cleanLine + '\n';
        }
      }
    });
    return sections;
  };

  const handleGenerate = async () => {
    if (!painPoint.trim()) return;
    setIsLoading(true);
    try {
      const result = await generateConsultantSolution(painPoint);
      setSolution(result || '');
      setIsLoading(false);
      setStep('result');
    } catch (error) {
      console.error(error);
      setIsLoading(false);
      alert('診斷過程中發生錯誤，請稍後再試。');
    }
  };

  const handleSendToConsultant = () => {
    setIsSendingEmail(true);
    setTimeout(() => {
      setIsSendingEmail(false);
      setStep('emailSent');
    }, 2000);
  };

  if (!isOpen) return null;
  const parsed = parseSolution(solution);

  return (
    <div className="fixed inset-0 z-[500] flex items-center justify-center p-4 md:p-8 bg-slate-950/95 backdrop-blur-3xl animate-in fade-in duration-500">
      <div className="bg-white w-full max-w-6xl rounded-[40px] overflow-hidden shadow-3xl relative border border-white/20 flex flex-col h-full md:h-auto md:max-h-[92vh]">
        <button onClick={onClose} className="absolute top-6 right-6 p-3 bg-slate-100 hover:bg-slate-200 rounded-full transition-all z-[70]">
          <X className="w-6 h-6 text-slate-600" />
        </button>

        <div className="p-6 md:p-12 overflow-y-auto no-scrollbar flex-1 relative bg-white">
          {isLoading && (
            <div className="absolute inset-0 z-[60] bg-white/98 backdrop-blur-2xl flex flex-col items-center justify-center space-y-8 animate-in fade-in">
              <div className="relative">
                <div className="w-24 h-24 bg-slate-950 rounded-[32px] flex items-center justify-center shadow-3xl animate-pulse ring-4 ring-purple-50">
                  <BrainCircuit className="w-10 h-10 text-[#7c3aed]" />
                </div>
                <div className="absolute -bottom-2 -right-2 bg-white p-1.5 rounded-xl shadow-2xl border border-slate-50">
                  <Loader2 className="w-8 h-8 text-[#7c3aed] animate-spin" />
                </div>
              </div>
              <div className="text-center">
                <h3 className="text-xl font-black text-slate-900 tracking-tight">TPI 戰略診斷大腦分析中</h3>
                <p className="text-slate-400 font-bold text-sm mt-2">正在為您量化 Before/After 預期效益...</p>
              </div>
            </div>
          )}

          {step === 'input' && (
            <div className="space-y-8 max-w-4xl mx-auto py-6">
              <div className="text-center space-y-3">
                <div className="w-16 h-16 bg-purple-50 rounded-[24px] flex items-center justify-center mx-auto border border-purple-100"><BrainCircuit className="w-10 h-10 text-[#7c3aed]" /></div>
                <h2 className="text-3xl font-black text-slate-900 tracking-tight">3 分鐘 AI 顧問診斷</h2>
                <p className="text-slate-500 font-bold text-base">描述您的業務痛點，獲取量化轉型報告</p>
              </div>
              <div className="relative">
                <textarea
                  value={painPoint}
                  onChange={(e) => setPainPoint(e.target.value)}
                  placeholder="請描述您的業務痛點（如：數據雜亂無法洞察、客服人力成本過高、開發效率低落等）..."
                  className="w-full h-56 bg-slate-50 border border-slate-100 rounded-[30px] p-8 text-lg font-bold outline-none focus:border-[#7c3aed] focus:bg-white transition-all shadow-inner placeholder:text-slate-300 resize-none"
                />
              </div>
              <button 
                onClick={handleGenerate} 
                disabled={!painPoint.trim()}
                className="w-full py-6 bg-slate-900 text-white rounded-[30px] font-black text-lg shadow-xl flex items-center justify-center gap-4 active:scale-[0.98] transition-all group disabled:opacity-40"
              >
                <Zap className="w-6 h-6 text-[#7c3aed]" /> 開始診斷方案
              </button>
            </div>
          )}

          {step === 'result' && (
            <div className="space-y-8 animate-in slide-in-from-bottom-6 max-w-5xl mx-auto">
              {/* Header - Compact */}
              <div className="flex items-center gap-4 pb-2 border-b border-slate-50">
                <div className="w-14 h-14 bg-green-50 rounded-2xl flex items-center justify-center"><ClipboardCheck className="w-8 h-8 text-green-600" /></div>
                <div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">AI 戰略初步診斷結果書</h3>
                  <p className="text-[#7c3aed] font-black text-[9px] uppercase tracking-[0.2em]">Personalized Transformation Analysis</p>
                </div>
              </div>

              {/* Core Suggestion Card - Black & Gold, Compact Height */}
              <div className="bg-[#0f172a] border border-[#d4af37]/40 rounded-[32px] p-8 shadow-2xl relative overflow-hidden flex flex-col md:flex-row items-center gap-8 min-h-[140px]">
                <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none">
                  <Crown className="w-40 h-40 text-[#d4af37]" />
                </div>
                <div className="relative z-10 flex flex-col gap-1 items-center md:items-start shrink-0 min-w-[140px]">
                  <div className="flex items-center gap-1.5 text-[#d4af37] font-black text-[10px] uppercase tracking-widest">
                    <Crown className="w-3.5 h-3.5" /> 核心建議
                  </div>
                  <div className="text-4xl font-black text-[#d4af37] tracking-tighter tabular-nums drop-shadow-md">
                    {parsed.ROI?.trim() || '400%+'}
                  </div>
                </div>
                <div className="h-px md:h-12 w-full md:w-px bg-white/10" />
                <div className="relative z-10 text-lg md:text-xl font-bold text-white/95 leading-snug text-center md:text-left italic">
                  「{parsed.SUMMARY?.trim() || '根據您的痛點，建議導入專屬 AI Agent 體系優化關鍵流程。'}」
                </div>
              </div>

              {/* Side-by-Side Comparison - Clear Visual Differentiation */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {/* BEFORE */}
                <div className="bg-[#f8fafc] border border-slate-200 p-7 rounded-[30px] space-y-4 shadow-sm border-l-4 border-l-slate-400 flex flex-col min-h-[180px]">
                  <div className="flex items-center gap-2 text-slate-500 font-black text-[10px] uppercase tracking-widest">
                    <ShieldAlert className="w-4 h-4" /> BEFORE：現狀與隱形成本
                  </div>
                  <div className="text-slate-600 font-bold text-sm leading-relaxed whitespace-pre-wrap flex-1 italic">
                    {parsed.BEFORE || '目前依賴人工處理，存在效率瓶頸與數據孤島問題。'}
                  </div>
                </div>

                {/* AFTER */}
                <div className="bg-gradient-to-br from-[#7c3aed] to-[#5b21b6] p-7 rounded-[30px] space-y-4 shadow-xl border-l-4 border-l-white flex flex-col min-h-[180px] text-white">
                  <div className="flex items-center gap-2 text-white/80 font-black text-[10px] uppercase tracking-widest">
                    <Zap className="w-4 h-4" /> AFTER：轉型後預期效益
                  </div>
                  <div className="text-white font-black text-sm leading-relaxed whitespace-pre-wrap flex-1 drop-shadow-sm">
                    {parsed.AFTER || '自動化水平提升 150%，且具備精準數據決策支持能力。'}
                  </div>
                </div>
              </div>

              {/* Bottom Actions - Fixed and Clear */}
              <div className="flex flex-col md:flex-row gap-4 pt-2">
                <button 
                  onClick={() => setStep('input')} 
                  className="px-8 py-4 bg-white border border-slate-200 text-slate-500 rounded-full font-black text-xs hover:bg-slate-50 transition-all active:scale-95"
                >
                  重新填寫診斷需求
                </button>
                <button 
                  onClick={handleSendToConsultant} 
                  disabled={isSendingEmail}
                  className="flex-1 py-4 bg-[#0f172a] text-white rounded-full font-black text-base shadow-xl flex items-center justify-center gap-3 hover:bg-slate-900 border border-[#d4af37]/20 active:scale-[0.98] transition-all"
                >
                  {isSendingEmail ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Mail className="w-5 h-5 text-[#d4af37]" /> 轉送 TPI 顧問，獲取完整深度報告</>}
                </button>
              </div>
            </div>
          )}

          {step === 'emailSent' && (
            <div className="py-20 text-center space-y-8 px-8 animate-in zoom-in-95 duration-500">
              <div className="w-24 h-24 bg-green-50 text-green-500 rounded-[32px] flex items-center justify-center mx-auto shadow-xl border-2 border-white">
                <CheckCircle2 className="w-12 h-12" />
              </div>
              <div className="space-y-3">
                <h3 className="text-3xl font-black text-slate-900 tracking-tight">戰略需求提交成功</h3>
                <p className="text-slate-500 font-bold max-w-md mx-auto leading-relaxed text-base">
                  您的診斷結果已成功送達 TPI 顧問團隊。我們將在 24 小時內指派專家與您聯繫，提供更具體的實施藍圖。
                </p>
              </div>
              <button onClick={onClose} className="px-12 py-5 bg-slate-950 text-white rounded-full font-black text-lg shadow-xl hover:bg-slate-800 transition-all active:scale-95">
                關閉並返回
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIConsultantModal;
