
import React, { useState } from 'react';
import { SuccessCase } from '../types';
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, ArrowUpRight } from 'lucide-react';

interface CaseCardProps {
  item: SuccessCase;
  onClick: () => void;
  onShare: () => void;
}

const CaseCard: React.FC<CaseCardProps> = ({ item, onClick, onShare }) => {
  const [liked, setLiked] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);

  return (
    <div className="bg-white border border-gray-100 rounded-[28px] overflow-hidden shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 flex flex-col group">
      {/* IG Style Header */}
      <div className="px-5 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center p-1.5 overflow-hidden ring-2 ring-purple-50">
            <div className="w-full h-full rounded-full bg-gradient-to-tr from-[#7c3aed] to-blue-500 flex items-center justify-center">
              <span className="text-[10px] font-black text-white">AI</span>
            </div>
          </div>
          <div>
            <h4 className="text-[14px] font-black text-slate-900 leading-tight">{item.client}</h4>
            <p className="text-[10px] text-[#7c3aed] font-black uppercase tracking-wider">{item.role}</p>
          </div>
        </div>
        <button className="p-2 hover:bg-slate-50 rounded-full transition-colors text-slate-300 hover:text-slate-600">
          <MoreHorizontal className="w-5 h-5" />
        </button>
      </div>

      {/* Main Image with Animated Results */}
      <div className="aspect-square relative cursor-pointer overflow-hidden bg-slate-100" onClick={onClick}>
        <img 
          src={item.imageUrl} 
          className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
          loading="lazy"
        />
        {/* Hover Overlay */}
        <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
           <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-slate-950 scale-50 group-hover:scale-100 transition-transform duration-500 shadow-2xl">
              <ArrowUpRight className="w-8 h-8" />
           </div>
        </div>
        
        <div className="absolute bottom-5 left-5">
           <span className="px-4 py-2 bg-white/95 backdrop-blur-md text-[#7c3aed] text-xs font-black rounded-xl shadow-xl border border-purple-50 group-hover:scale-110 transition-transform">
              {item.results}
           </span>
        </div>
      </div>

      {/* Action Bar */}
      <div className="px-5 pt-4 pb-3 flex items-center justify-between">
        <div className="flex items-center gap-5">
          <Heart 
            onClick={() => setLiked(!liked)} 
            className={`w-7 h-7 cursor-pointer transition-all active:scale-150 ${liked ? 'fill-red-500 text-red-500' : 'text-slate-800 hover:text-red-500'}`} 
          />
          <MessageCircle onClick={onClick} className="w-7 h-7 text-slate-800 hover:text-[#7c3aed] cursor-pointer transition-colors" />
          <Share2 onClick={onShare} className="w-7 h-7 text-slate-800 hover:text-[#7c3aed] cursor-pointer transition-colors" />
        </div>
        <Bookmark 
          onClick={() => setBookmarked(!bookmarked)} 
          className={`w-7 h-7 cursor-pointer transition-all active:scale-125 ${bookmarked ? 'fill-slate-900 text-slate-900' : 'text-slate-800 hover:text-[#7c3aed]'}`} 
        />
      </div>

      {/* Content Area */}
      <div className="px-5 pb-7 space-y-3">
        <p className="text-[16px] leading-tight font-black text-slate-900 line-clamp-1 group-hover:text-[#7c3aed] transition-colors">{item.title}</p>
        <p className="text-[14px] text-slate-500 line-clamp-2 leading-relaxed font-medium">
          {item.summary}
        </p>
        
        <div className="flex flex-wrap gap-x-3 gap-y-1 pt-2">
          {item.tags.map((tag, idx) => (
            <span key={idx} className="text-[13px] font-bold text-[#00376b] hover:text-[#7c3aed] transition-colors cursor-pointer">
              #{tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CaseCard;
