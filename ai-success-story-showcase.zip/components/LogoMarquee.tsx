
import React, { useState } from 'react';

const LogoMarquee: React.FC = () => {
  const [loadedImages, setLoadedImages] = useState<Record<string, boolean>>({});

  const handleImageLoad = (id: string) => {
    setLoadedImages(prev => ({ ...prev, [id]: true }));
  };

  const partners = [
    { 
      name: 'Google Cloud', 
      logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Google_Cloud_logo.svg/512px-Google_Cloud_logo.svg.png' 
    },
    { 
      name: 'Microsoft', 
      logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Microsoft_logo.svg/512px-Microsoft_logo.svg.png' 
    },
    { 
      name: 'AWS', 
      logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Amazon_Web_Services_Logo.svg/512px-Amazon_Web_Services_Logo.svg.png' 
    },
    { 
      name: 'OpenAI', 
      logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/OpenAI_Logo.svg/512px-OpenAI_Logo.svg.png' 
    },
    { 
      name: '華碩電腦 (ASUS)', 
      logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/ASUS_Logo.svg/512px-ASUS_Logo.svg.png' 
    },
  ];

  const renderLogo = (partner: typeof partners[0], index: number, isDuplicate: boolean) => {
    const id = `${isDuplicate ? 'dup-' : ''}${index}-${partner.name}`;
    return (
      <div key={id} className="mx-12 md:mx-20 flex items-center justify-center grayscale hover:grayscale-0 transition-all duration-700 hover:scale-110 min-w-[120px]">
        <img 
          src={partner.logo} 
          alt={partner.name} 
          className={`h-10 md:h-12 w-auto object-contain max-w-[180px] transition-opacity duration-500 ${loadedImages[id] ? 'opacity-100' : 'opacity-0'}`}
          loading="lazy"
          onLoad={() => handleImageLoad(id)}
          onError={(e) => {
            (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(partner.name)}&background=f8fafc&color=94a3b8&bold=true&size=128`;
            handleImageLoad(id); // Ensure it displays even if fallback is used
          }}
        />
      </div>
    );
  };

  return (
    <div className="py-20 bg-white border-y border-slate-100 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-6 mb-12 flex items-center justify-center">
         <div className="flex items-center gap-6">
            <div className="h-px w-12 bg-slate-200"></div>
            <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.5em] text-center">Our Strategic Partner and Clients</h4>
            <div className="h-px w-12 bg-slate-200"></div>
         </div>
      </div>
      
      <div className="relative flex overflow-x-hidden group">
        <div className="py-4 animate-marquee flex items-center whitespace-nowrap">
          {partners.map((partner, idx) => renderLogo(partner, idx, false))}
          {partners.map((partner, idx) => renderLogo(partner, idx, true))}
        </div>

        <div className="absolute top-0 py-4 animate-marquee2 flex items-center whitespace-nowrap">
          {partners.map((partner, idx) => renderLogo(partner, idx, false))}
          {partners.map((partner, idx) => renderLogo(partner, idx, true))}
        </div>
      </div>

      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0%); }
          100% { transform: translateX(-100%); }
        }
        @keyframes marquee2 {
          0% { transform: translateX(100%); }
          100% { transform: translateX(0%); }
        }
        .animate-marquee { animation: marquee 30s linear infinite; }
        .animate-marquee2 { animation: marquee2 30s linear infinite; }
        .group:hover .animate-marquee, 
        .group:hover .animate-marquee2 { animation-play-state: paused; }
      `}</style>
    </div>
  );
};

export default LogoMarquee;
