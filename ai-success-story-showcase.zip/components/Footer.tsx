
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 text-white py-24 px-8 md:px-16 mt-32">
      <div className="max-w-[1440px] mx-auto flex flex-col md:flex-row justify-between items-start gap-16">
        <div className="flex flex-col items-start max-w-md">
          <h2 className="text-4xl font-black tracking-tighter">
            <span className="text-[#7c3aed]">TPI</span>software
          </h2>
          <p className="text-slate-400 text-sm font-black mt-4 uppercase tracking-[0.4em]">You AI Partner for Mission-Critical Success</p>
          <p className="text-slate-500 text-sm font-bold mt-8 leading-relaxed">
            身為企業數位轉型之領導者，我們專注於將最尖端的生成式 AI 技術轉化為可落地、可規模化的商業產值。
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-16 flex-1">
          <div>
            <h4 className="text-[12px] font-black text-[#7c3aed] uppercase tracking-[0.3em] mb-6">全球佈局 Global Presence</h4>
            <div className="space-y-4 text-slate-300 font-bold text-sm">
              <p className="flex justify-between border-b border-white/5 pb-2"><span>台北 Taipei</span> <span className="text-slate-600 uppercase text-[10px]">Headquarters</span></p>
              <p className="flex justify-between border-b border-white/5 pb-2"><span>東京 Tokyo</span> <span className="text-slate-600 uppercase text-[10px]">Branch</span></p>
              <p className="flex justify-between border-b border-white/5 pb-2"><span>新加坡 Singapore</span> <span className="text-slate-600 uppercase text-[10px]">Branch</span></p>
              <p className="flex justify-between border-b border-white/5 pb-2"><span>胡志明 Ho Chi Minh</span> <span className="text-slate-600 uppercase text-[10px]">Offshore Hub</span></p>
            </div>
          </div>
          
          <div>
            <h4 className="text-[12px] font-black text-[#7c3aed] uppercase tracking-[0.3em] mb-6">聯繫我們 Contact</h4>
            <p className="text-xl font-black text-white mb-2">consultant@tpisoftware.com</p>
            <p className="text-slate-500 text-sm font-bold">台北市內湖區瑞光路437號</p>
          </div>

          <div>
            <h4 className="text-[12px] font-black text-[#7c3aed] uppercase tracking-[0.3em] mb-6">專業認證 Certified</h4>
            <div className="flex flex-wrap gap-4 opacity-50 grayscale hover:grayscale-0 transition-all">
               <div className="bg-white/10 px-4 py-2 rounded-lg font-black text-[10px]">ISO 27001</div>
               <div className="bg-white/10 px-4 py-2 rounded-lg font-black text-[10px]">專利持有超過20項</div>
               <div className="bg-white/10 px-4 py-2 rounded-lg font-black text-[10px]">OpenAI Partner</div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-[1440px] mx-auto border-t border-white/10 mt-20 pt-10 flex flex-col md:flex-row justify-between items-center gap-6">
        <p className="text-xs font-bold text-slate-600 uppercase tracking-widest">© 2026 TPIsoftware Corp. All rights reserved. Powered by TPI AI-Core.</p>
        <div className="flex gap-8">
          <a href="#" className="text-xs font-black text-slate-600 hover:text-[#7c3aed] transition-colors uppercase tracking-widest">Privacy Policy</a>
          <a href="#" className="text-xs font-black text-slate-600 hover:text-[#7c3aed] transition-colors uppercase tracking-widest">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
