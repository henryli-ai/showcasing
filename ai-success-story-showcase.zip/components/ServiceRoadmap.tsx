
import React, { forwardRef, useState } from 'react';
import { Target, Map, TrendingUp, ShieldCheck, ChevronRight, UserCheck, Code2, Database, BarChart3, Lock, Sparkles, Zap, GraduationCap, Award } from 'lucide-react';

const ServiceRoadmap = forwardRef<HTMLDivElement>((props, ref) => {
  const [logoLoaded, setLogoLoaded] = useState(false);

  const steps = [
    {
      title: '企業策略目標',
      subtitle: 'Strategy',
      duration: '1-2 週',
      items: ['情境與範圍界定', 'AI 主權與治理框架', '資訊體質診斷', '技術移轉規劃'],
      icon: <Target className="w-8 h-8 text-purple-600" />,
      color: 'bg-purple-50/50',
      border: 'border-purple-100'
    },
    {
      title: '導入藍圖',
      subtitle: 'Enablement',
      duration: '4-12 週',
      items: ['共創價值 Lab', '無幻覺架構部署', '資安與護欄佈署', '種子導師培訓'],
      icon: <Map className="w-6 h-6 text-blue-600" />,
      color: 'bg-blue-50/50',
      border: 'border-blue-100'
    },
    {
      title: 'AI 能力演進',
      subtitle: 'AI Capability Subscription',
      duration: '長期赋能',
      items: ['治理政策校準', 'Know-how 移轉', 'RAG 品質持續優化', '模型自主微調'],
      icon: <TrendingUp className="w-6 h-6 text-green-600" />,
      color: 'bg-green-50/50',
      border: 'border-green-100'
    }
  ];

  const highlights = [
    { title: '無幻覺 AI 引擎', desc: '基於 RAG 與嚴謹護欄，確保答案 100% 基於企業知識庫。', icon: <ShieldCheck className="w-5 h-5" /> },
    { title: '全面技術移轉', desc: '不只是交付產品，更提供原始碼與工程團隊實戰培訓。', icon: <GraduationCap className="w-5 h-5" /> },
    { title: '可信賴導入架構', desc: '支援私有化部署，確保敏感數據不出企業邊界。', icon: <Zap className="w-5 h-5" /> }
  ];

  return (
    <div ref={ref} className="py-32 px-6 bg-slate-50/50 border-t border-slate-100">
      <div className="max-w-7xl mx-auto space-y-20">
        
        {/* OpenAI Partnership Badge */}
        <div className="bg-white border-2 border-[#7c3aed]/30 rounded-[40px] p-8 md:p-14 flex flex-col md:flex-row items-center justify-between gap-12 shadow-2xl shadow-purple-100/50 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-10 opacity-[0.05] group-hover:scale-110 transition-transform duration-1000">
            <Award className="w-72 h-72 text-[#7c3aed]" />
          </div>
          <div className="relative z-10 flex flex-col md:flex-row items-center gap-10 text-center md:text-left">
            <div className="w-36 h-36 bg-slate-900 rounded-[40px] flex items-center justify-center p-8 shadow-2xl ring-8 ring-purple-50">
              <img 
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/OpenAI_Logo.svg/512px-OpenAI_Logo.svg.png" 
                alt="OpenAI" 
                className={`w-full invert transition-opacity duration-500 ${logoLoaded ? 'opacity-100' : 'opacity-0'}`} 
                onLoad={() => setLogoLoaded(true)}
                loading="lazy"
              />
            </div>
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-5 py-2 bg-[#7c3aed] text-white rounded-full text-[12px] font-black uppercase tracking-[0.2em] shadow-lg shadow-purple-200">
                <Award className="w-4 h-4" /> OpenAI 台灣唯一合作夥伴
              </div>
              <h3 className="text-4xl font-black text-slate-900 leading-tight">獨家對接官方模型技術</h3>
              <p className="text-slate-500 font-bold text-lg max-w-xl">身為台灣首家官方合作夥伴，我們掌握最前端的模型微調與安全整合方案，確保企業在大模型競爭中佔據絕對優勢。</p>
            </div>
          </div>
          <div className="relative z-10 hidden lg:block shrink-0">
             {/* Removed Verified Agency 2024 badge as requested */}
          </div>
        </div>

        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 pt-10">
          <div className="space-y-4 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-purple-100 text-[#7c3aed] rounded-full text-[10px] font-black uppercase tracking-widest">
              <Sparkles className="w-3 h-3" /> Professional Service
            </div>
            <h2 className="text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-tight">
              專業 AI 導入顧問服務<br/>
              <span className="text-[#7c3aed]">打造可信任的企業大腦</span>
            </h2>
          </div>
        </div>

        {/* Key Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {highlights.map((h, i) => (
            <div key={i} className="bg-white p-10 rounded-[40px] border border-slate-100 shadow-sm space-y-5 hover:shadow-xl transition-all duration-500 group">
              <div className="w-14 h-14 bg-slate-900 text-white rounded-2xl flex items-center justify-center group-hover:bg-[#7c3aed] transition-colors duration-500">
                {h.icon}
              </div>
              <h4 className="text-xl font-black text-slate-900">{h.title}</h4>
              <p className="text-slate-500 text-sm font-medium leading-relaxed">{h.desc}</p>
            </div>
          ))}
        </div>

        {/* Main Roadmap */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 relative">
          {steps.map((step, idx) => (
            <div key={idx} className="relative group">
              <div className={`h-full p-10 rounded-[45px] border-2 ${step.border} ${step.color} backdrop-blur-sm transition-all duration-500 group-hover:shadow-2xl group-hover:bg-white`}>
                <div className="flex justify-between items-start mb-10">
                  <div className="p-5 bg-white rounded-2xl shadow-sm">
                    {step.icon}
                  </div>
                  <span className="text-[10px] font-black bg-white/80 px-5 py-2 rounded-full text-slate-400 uppercase tracking-widest border border-white/50">
                    {step.duration}
                  </span>
                </div>
                
                <div className="space-y-1 mb-10">
                  <h3 className="text-2xl font-black text-slate-900">{step.title}</h3>
                  <p className="text-slate-400 font-black text-[10px] uppercase tracking-[0.2em]">{step.subtitle}</p>
                </div>

                <ul className="space-y-5">
                  {step.items.map((item, i) => (
                    <li key={i} className="flex items-center gap-4 text-slate-600 font-bold text-sm">
                      <div className="w-2 h-2 bg-[#7c3aed]/20 rounded-full" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              
              {idx < steps.length - 1 && (
                <div className="hidden lg:flex absolute -right-4 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-white border border-slate-100 rounded-full items-center justify-center shadow-lg">
                  <ChevronRight className="w-6 h-6 text-slate-300" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Tech Transfer Banner */}
        <div className="bg-slate-900 rounded-[50px] p-12 lg:p-20 overflow-hidden relative shadow-3xl">
          <div className="absolute top-0 right-0 p-10 opacity-[0.08] pointer-events-none">
             <ShieldCheck className="w-80 h-80 text-white" />
          </div>
          <div className="relative z-10 flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/3 space-y-4 text-center lg:text-left">
              <h4 className="text-3xl font-black text-white leading-tight">企業 AI 治理<br/>與技術移轉專區</h4>
              <p className="text-slate-400 text-[11px] font-black uppercase tracking-[0.3em]">Scalable Infrastructure</p>
            </div>
            <div className="flex-1 grid grid-cols-2 md:grid-cols-3 gap-8 w-full">
              {[
                { label: '多層次權限管理', icon: <UserCheck className="w-5 h-5" /> },
                { label: '無幻覺 Prompt 工程', icon: <Code2 className="w-5 h-5" /> },
                { label: '專利 RAG 品質控制', icon: <Database className="w-5 h-5" /> },
                { label: '原始碼完整移轉', icon: <GraduationCap className="w-5 h-5" /> },
                { label: '高強度數據安全護欄', icon: <Lock className="w-5 h-5" /> },
                { label: 'ROI 效益實時追蹤', icon: <BarChart3 className="w-5 h-5" /> }
              ].map((item, idx) => (
                <div key={idx} className="flex flex-col gap-4 group">
                  <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-[#7c3aed] transition-all duration-500 group-hover:bg-[#7c3aed] group-hover:text-white">
                    {item.icon}
                  </div>
                  <span className="text-white font-bold text-xs lg:text-sm">{item.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});

ServiceRoadmap.displayName = 'ServiceRoadmap';
export default ServiceRoadmap;
