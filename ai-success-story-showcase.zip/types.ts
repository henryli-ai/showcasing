
export type Role = 
  | 'SoftwareDevelopment' 
  | 'CustomerExperience' 
  | 'MarketingCreative' 
  | 'OperationsEfficiency' 
  | 'DataInsight' 
  | 'ProfessionalServices' 
  | 'All';

export type Industry = 
  | 'Finance' 
  | 'Healthcare' 
  | 'Retail' 
  | 'Technology' 
  | 'Manufacturing' 
  | 'PublicSector' 
  | 'All';

export interface BusinessImpact {
  label: string;
  value: string;
}

export interface SuccessCase {
  id: string;
  title: string;
  client: string;
  role: Role;
  industry: Industry;
  summary: string;
  detailedContent: string;
  imageUrl: string;
  videoUrl?: string;
  tags: string[];
  date: string;
  results: string;
  nps?: number; // 新增 NPS 分數
  businessImpact?: BusinessImpact[];
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}
