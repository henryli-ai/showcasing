
import { SuccessCase } from './types';

// 生成更多案例的輔助函數 (模擬數據)
const generateMoreCases = (): SuccessCase[] => {
  const baseCases: SuccessCase[] = [
    {
      id: 'f1',
      title: '頂尖金融集團：AI 全自動現代化流水線',
      client: '頂尖金融集團',
      role: 'SoftwareDevelopment',
      industry: 'Finance',
      summary: '利用大語言模型加速遺留代碼遷移，將 Legacy 系統遷移效率提升 3 倍。',
      detailedContent: '我們為客戶建立了端到端的 AI 代碼現代化流水線，自動分析數百萬行遺留代碼，確保業務連續性與安全性。',
      imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800',
      tags: ['代碼生成', '雲端遷移', '金融科技'],
      date: '2026/03/15',
      results: '重構耗時降低 65%',
      nps: 9.8,
      businessImpact: [{ label: '人天成本節省', value: '450+ 人月' }, { label: '代碼準確度', value: '94%' }]
    },
    {
      id: 'p1',
      title: 'PKSHA 官方合作：次世代 AI 語音客服系統',
      client: '日本頂級零售集團',
      role: 'CustomerExperience',
      industry: 'Retail',
      summary: '導入 PKSHA 語音識別技術，實現 24/7 全自動化預約與投訴處理。',
      detailedContent: '結合 TPI 繁中優化引擎，為客戶打造無縫語音體驗，並整合後端訂單系統。',
      imageUrl: 'https://images.unsplash.com/photo-1534536281715-e28d76689b4d?auto=format&fit=crop&q=80&w=800',
      tags: ['語音AI', '自動化', 'PKSHA'],
      date: '2026/06/10',
      results: '人工成本降低 45%',
      nps: 9.9,
      businessImpact: [{ label: '平均應答時間', value: '-80%' }, { label: '處理容量提升', value: '12 倍' }]
    },
    {
      id: 't1',
      title: 'Tomoro.ai 實踐：企業級 AI Agent 法律智庫',
      client: '全球領先諮詢公司',
      role: 'ProfessionalServices',
      industry: 'Technology',
      summary: '受 Tomoro.ai 啟發，部署自主代理人流程，自動處理複雜的法律合約審查。',
      detailedContent: '透過多代理人協作架構 (Multi-Agent Workflows)，AI Agent 能夠自主進行法律風險評估。',
      imageUrl: 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&q=80&w=800',
      tags: ['AI-Agents', '智庫', 'Tomoro'],
      date: '2026/08/22',
      results: '審查速度提升 15 倍',
      nps: 9.8,
      businessImpact: [{ label: '合規率', value: '100%' }, { label: '專家時間', value: '70%' }]
    }
  ];

  const roles: string[] = ['SoftwareDevelopment', 'CustomerExperience', 'MarketingCreative', 'OperationsEfficiency', 'DataInsight', 'ProfessionalServices'];
  const industries: string[] = ['Finance', 'Healthcare', 'Retail', 'Technology', 'Manufacturing', 'PublicSector'];
  
  const additionalCases: SuccessCase[] = [];
  let idCounter = 100;

  // 確保每個 Role 和 Industry 的組合都有案例
  roles.forEach(role => {
    industries.forEach(industry => {
      additionalCases.push({
        id: `gen-${idCounter++}`,
        title: `${industry} 產業 ${role} 智慧優化專案`,
        client: `領先 ${industry} 企業`,
        role: role as any,
        industry: industry as any,
        summary: `針對 ${industry} 產業開發的專屬 ${role} 解決方案，顯著提升營運指標。`,
        detailedContent: `這是一個關於 ${industry} 產業如何透過 TPIsoftware 的 ${role} 技術實現轉型的深度案例。`,
        imageUrl: `https://picsum.photos/seed/${idCounter}/800/800`,
        tags: [role, industry, 'AI-Transformation'],
        date: '2026/01/01',
        results: '效率提升 40%+',
        nps: 9.5
      });
    });
  });

  return [...baseCases, ...additionalCases].slice(0, 52);
};

export const INITIAL_CASES: SuccessCase[] = generateMoreCases();

export const CATEGORIES = [
  { id: 'All', label: '全部解決方案', icon: '✨' },
  { id: 'SoftwareDevelopment', label: '軟體開發', icon: '🛠️' },
  { id: 'CustomerExperience', label: '客戶體驗', icon: '💬' },
  { id: 'MarketingCreative', label: '行銷創意', icon: '🎨' },
  { id: 'OperationsEfficiency', label: '營運效率', icon: '⚡' },
  { id: 'DataInsight', label: '數據洞察', icon: '📈' },
  { id: 'ProfessionalServices', label: '專業服務', icon: '💼' },
];

export const INDUSTRIES = [
  { id: 'All', label: '所有產業', icon: '🏢' },
  { id: 'Finance', label: '金融保險', icon: '🏦' },
  { id: 'Healthcare', label: '醫療保健', icon: '🏥' },
  { id: 'Retail', label: '零售消費', icon: '🛍️' },
  { id: 'Technology', label: '科技通訊', icon: '📱' },
  { id: 'Manufacturing', label: '製造工業', icon: '🏗️' },
  { id: 'PublicSector', label: '公共部門', icon: '🏛️' },
];
