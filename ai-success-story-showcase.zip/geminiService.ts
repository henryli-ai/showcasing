import { GoogleGenAI, Type } from "@google/genai";
import { SuccessCase, Role, Industry } from "./types";

const getAiInstance = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * [System Instruction - 智能客服導覽]
 * 角色：TPIsoftware 頂級企業 AI 顧問。
 * 規則：極簡回答（<50字）、列點呈現、引導至案例 ID。
 */
export const askAiAboutCases = async (query: string, cases: SuccessCase[], chatHistory: any[] = []) => {
  const ai = getAiInstance();
  const casesContext = cases.map(c => `[ID: ${c.id}] ${c.title}`).join(', ');

  const systemInstruction = `
    你現在扮演 TPIsoftware 頂級企業 AI 顧問。
    規則：
    1. **極簡回答**：總字數必須低於 50 字。
    2. **格式**：一律使用「•」列點呈現。
    3. **引導**：回答後必須推薦相關案例，格式為 [案例: ID]。
    現有案例庫：${casesContext}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...chatHistory,
        { role: 'user', parts: [{ text: query }] }
      ],
      config: {
        systemInstruction,
        temperature: 0.6,
      },
    });

    return response.text;
  } catch (error) {
    console.error("AI Service Error:", error);
    return "• 系統連線繁忙，請稍後再試。";
  }
};

/**
 * [System Instruction - 案例自動生成]
 * 角色：專業 AI 顧問。
 * 任務：將用戶上傳的文件/圖片/音檔轉化為標準成功案例格式，年份定為 2026。
 */
export const generateCaseDataFromAI = async (inputParts: any[]) => {
  const ai = getAiInstance();
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: [{ parts: inputParts }],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          client: { type: Type.STRING },
          role: { type: Type.STRING },
          industry: { type: Type.STRING },
          summary: { type: Type.STRING },
          detailedContent: { type: Type.STRING },
          results: { type: Type.STRING },
          impacts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                label: { type: Type.STRING },
                value: { type: Type.STRING }
              },
              required: ['label', 'value']
            }
          },
          imagePrompt: { type: Type.STRING }
        },
        required: ['title', 'client', 'role', 'industry', 'summary', 'detailedContent', 'results', 'impacts', 'imagePrompt']
      },
      systemInstruction: "你是一個專業的 AI 顧問。將用戶輸入的資料轉化為結構化的企業成功案例。確保數據量化且具備商業價值。年份統一標註為 2026 年。"
    }
  });

  return JSON.parse(response.text);
};

/**
 * [System Instruction - 核心戰略診斷大腦]
 * 角色：TPIsoftware 資深 AI 戰略架構師。
 * 任務：深度分析客戶痛點並提供量化 Before/After 效益。
 */
export const generateConsultantSolution = async (painPoint: string) => {
  const ai = getAiInstance();
  
  const systemInstruction = `
    你現在扮演 TPIsoftware 資深 AI 戰略架構師。
    任務：針對用戶提供的痛點描述，給出 AI 可以協助的解決方案。
    
    格式規範（嚴格遵守 [標籤]）：
    [SUMMARY] 概要說明：精簡描述解決方案的核心概念。
    [BEFORE] 現狀分析：精準重述用戶輸入的問題，並估算當前的隱形成本與痛點影響。
    [AFTER] 導入後效益：描述導入 AI 解決方案後的具體轉變與量化效益 (如：效率提升倍數、成本節省比例)。
    [ROI] 量化指標：給出一個最具代表性的商業價值指標。

    總字數限制：250 字以內。
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [{ role: 'user', parts: [{ text: painPoint }] }],
      config: {
        systemInstruction,
        temperature: 0.4,
      },
    });

    return response.text;
  } catch (error) {
    return "[SUMMARY]\n診斷大腦連線異常。\n[ROI]\n待評估";
  }
};

export const generateCaseImage = async (prompt: string) => {
  const ai = getAiInstance();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [{ text: `High-tech enterprise visual, cinematic lighting, corporate aesthetic: ${prompt}` }]
    },
    config: { imageConfig: { aspectRatio: "16:9" } }
  });
  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  return "https://images.unsplash.com/photo-1639322537228-f710d846310a?auto=format&fit=crop&q=80&w=800";
};