
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { INITIAL_CASES, CATEGORIES, INDUSTRIES } from './constants';
import { SuccessCase, Role, Industry } from './types';
import CaseCard from './components/CaseCard';
import AIChat from './components/AIChat';
import UploadPortal from './components/UploadPortal';
import AIConsultantModal from './components/AIConsultantModal';
import ServiceRoadmap from './components/ServiceRoadmap';
import LogoMarquee from './components/LogoMarquee';
import Footer from './components/Footer';
import { X, Bot, Globe, CheckCircle2, Search, BrainCircuit, Zap, Sparkles, Mail, Send, ExternalLink, Calendar, Award, ShieldCheck, Filter, Crown } from 'lucide-react';

const App: React.FC = () => {
  const [cases, setCases] = useState<SuccessCase[]>(INITIAL_CASES);
  const [selectedRole, setSelectedRole] = useState<Role>('All');
  const [selectedIndustry, setSelectedIndustry] = useState<Industry>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isConsultantOpen, setIsConsultantOpen] = useState(false);
  const [isRoadmapOpen, setIsRoadmapOpen] = useState(false);
  const [selectedCase, setSelectedCase] = useState<SuccessCase | null>(null);
  const [showToast, setShowToast] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const [visibleCount, setVisibleCount] = useState(9);
  
  const [showWhitepaperForm, setShowWhitepaperForm] = useState(false);
  const [whitepaperEmail, setWhitepaperEmail] = useState('');

  const caseGridRef = useRef<HTMLDivElement>(null);

  const filteredCases = useMemo(() => {
    return cases.filter(c => {
      const matchesRole = selectedRole === 'All' || c.role === selectedRole;
      const matchesIndustry = selectedIndustry === 'All' || c.industry === selectedIndustry;
      const matchesSearch = searchQuery.trim() === '' || 
        c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.client.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesRole && matchesIndustry && matchesSearch;
    });
  }, [cases, selectedRole, selectedIndustry, searchQuery]);

  const scrollToCases = () => {
    if (caseGridRef.current) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = caseGridRef.current.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      window.scrollTo({ top: elementPosition - offset, behavior: 'smooth' });
    }
  };

  const handleFilterClick = (type: 'role' | 'industry', value: any) => {
    if (type === 'role') setSelectedRole(value);
    else setSelectedIndustry(value);
    setVisibleCount(9);
    setTimeout(scrollToCases, 100);
  };

  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  const handleWhitepaperSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!whitepaperEmail) return;
    triggerToast('2026 AI 戰略白皮書已發送至您的信箱');
    setShowWhitepaperForm(false);
    setWhitepaperEmail('');
  };

  return (
    <div className="min-h-screen bg-[#fcfdfe] font-sans selection:bg-purple-100">
      {showToast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[600] animate-in fade-in slide-in-from-top-4 w-[90%] md:w-auto">
          <div className="bg-slate-900 text-white px-6 py-3 rounded-full shadow-2xl flex items-center justify-center gap-3 border border-white/10">
            <CheckCircle2 className="w-5 h-5 text-green-400 shrink-0" />
            <span className="text-xs md:text-sm font-black whitespace-nowrap">{toastMsg}</span>
          </div>
        </div>
      )}

      {/* 導覽列 */}
      <nav className="sticky top-0 z-[100] bg-white/95 backdrop-blur-md border-b border-gray-100 px-6 md:px-12 py-3 flex items-center justify-between">
        <div className="flex flex-col cursor-pointer shrink-0" onClick={() => window.location.reload()}>
          <h1 className="text-xl font-black tracking-tighter leading-none">
            <span className="text-[#7c3aed]">TPI</span><span className="text-slate-900">software</span>
          </h1>
          <span className="text-[9px] font-bold text-slate-400 mt-1 hidden sm:block">You AI Partner for Mission-Critical Success</span>
        </div>

        <div className="flex-1 max-w-lg mx-10 hidden md:block">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-[#7c3aed] transition-colors" />
            <input 
              type="text" 
              placeholder="搜尋案例..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-100 border-none rounded-full py-2 pl-12 pr-6 text-sm font-bold outline-none focus:ring-2 focus:ring-purple-200 focus:bg-white transition-all"
            />
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button onClick={() => triggerToast('網址已複製')} className="p-2 bg-slate-50 text-slate-400 hover:text-[#7c3aed] rounded-full border border-slate-100 hidden sm:block">
            <Globe className="w-5 h-5" />
          </button>
          <button onClick={() => setIsUploadOpen(true)} className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-[#7c3aed] to-[#5b21b6] text-white rounded-full font-black text-xs shadow-lg shadow-purple-200/50 hover:brightness-110 transition-all active:scale-95">
            <Sparkles className="w-4 h-4" /> <span>發佈案例</span>
          </button>
        </div>
      </nav>

      <main className="max-w-[1440px] mx-auto px-6 md:px-12 pt-6 pb-24">
        
        {/* 1. 解決方案分類 (上移且更緊湊) */}
        <div className="flex justify-center items-start gap-8 md:gap-12 mb-10 overflow-x-auto no-scrollbar pb-2 px-4">
          {CATEGORIES.map(cat => (
            <button 
              key={cat.id} 
              onClick={() => handleFilterClick('role', cat.id as Role)}
              className="flex flex-col items-center gap-2 group shrink-0"
            >
              <div className={`w-14 h-14 md:w-16 md:h-16 rounded-full flex items-center justify-center text-xl md:text-2xl transition-all duration-300 relative ${selectedRole === cat.id ? 'scale-110' : 'hover:scale-105'}`}>
                 <div className={`absolute -inset-1 rounded-full border-[3px] transition-all ${selectedRole === cat.id ? 'border-[#7c3aed] opacity-100' : 'border-transparent opacity-0 group-hover:opacity-20 group-hover:border-slate-400'}`} />
                 <div className="w-full h-full bg-white rounded-full flex items-center justify-center shadow-md border border-slate-50">
                   {cat.icon}
                 </div>
              </div>
              <span className={`text-[11px] md:text-[12px] font-black tracking-tight transition-colors ${selectedRole === cat.id ? 'text-slate-900' : 'text-slate-400 group-hover:text-slate-600'}`}>
                {cat.label}
              </span>
            </button>
          ))}
        </div>

        {/* 2. 產業類別與動作卡片 (佈局優化) */}
        <div className="flex flex-col lg:flex-row gap-4 mb-10 items-stretch">
          
          {/* 左側：產業類別區 (白色圓角容器) */}
          <div className="flex-[4] bg-white border border-gray-100 rounded-[24px] p-3 flex items-center shadow-sm overflow-hidden">
             <div className="flex items-center gap-2 text-slate-400 font-black text-[10px] uppercase tracking-widest shrink-0 border-r border-slate-100 pr-4 pl-2">
                <Filter className="w-3.5 h-3.5" /> 產業
             </div>
             <div className="flex gap-2 overflow-x-auto no-scrollbar py-1 pl-4">
                {INDUSTRIES.map(ind => (
                  <button 
                    key={ind.id} 
                    onClick={() => handleFilterClick('industry', ind.id as Industry)}
                    className={`px-5 py-2 rounded-full text-[11px] font-black transition-all whitespace-nowrap flex items-center gap-2 border ${selectedIndustry === ind.id ? 'bg-[#0f172a] text-white border-[#0f172a] shadow-md' : 'bg-slate-50 text-slate-500 hover:bg-white hover:border-slate-200 border-transparent'}`}
                  >
                    <span className="opacity-80">{ind.icon}</span> {ind.label}
                  </button>
                ))}
             </div>
          </div>

          {/* 右側：動作小方塊 (貴族紫 & 黑金 優化) */}
          <div className="flex flex-row lg:flex-col gap-3 min-w-[240px]">
            {/* AI 診斷：貴族紫配色 */}
            <button 
              onClick={() => setIsConsultantOpen(true)} 
              className="flex-1 flex flex-col items-start gap-1 px-5 py-3 bg-gradient-to-br from-[#7c3aed] to-[#5b21b6] text-white rounded-2xl hover:brightness-110 shadow-lg shadow-purple-100/50 transition-all group relative overflow-hidden active:scale-95"
            >
              <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:scale-125 transition-transform">
                <BrainCircuit className="w-12 h-12" />
              </div>
              <div className="flex items-center gap-1.5 text-white/70 font-black text-[9px] uppercase tracking-wider">
                <BrainCircuit className="w-3 h-3" /> AI DIAGNOSTIC
              </div>
              <p className="text-[13px] font-black leading-tight">3 分鐘 AI 診斷</p>
            </button>

            {/* OpenAI 夥伴：黑金配色 */}
            <button 
              onClick={() => setIsRoadmapOpen(true)} 
              className="flex-1 flex flex-col items-start gap-1 px-5 py-3 bg-[#0f172a] border border-[#d4af37]/40 text-[#d4af37] rounded-2xl hover:bg-slate-900 shadow-xl transition-all group relative overflow-hidden active:scale-95"
            >
              <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:scale-125 transition-transform text-[#d4af37]">
                <Crown className="w-12 h-12" />
              </div>
              <div className="flex items-center gap-1.5 text-[#d4af37]/60 font-black text-[9px] uppercase tracking-wider">
                <Award className="w-3 h-3" /> PARTNERS
              </div>
              <p className="text-[13px] font-black leading-tight text-white group-hover:text-[#d4af37] transition-colors">OPENAI 夥伴服務</p>
            </button>
          </div>
        </div>

        {/* 成功案例展示區 - 佔據下 2/3 */}
        <div ref={caseGridRef} className="min-h-[600px]">
          {filteredCases.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 md:gap-14 animate-in fade-in slide-in-from-bottom-4 duration-500">
              {filteredCases.slice(0, visibleCount).map(c => (
                <CaseCard key={c.id} item={c} onClick={() => setSelectedCase(c)} onShare={() => {
                  navigator.clipboard.writeText(`${window.location.origin}${window.location.pathname}?caseId=${c.id}`);
                  triggerToast('專案連結已複製');
                }} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-44 bg-white/50 border-2 border-dashed border-slate-100 rounded-[40px]">
              <Search className="w-16 h-16 mb-6 text-slate-200" />
              <p className="text-xl font-black text-slate-400">目前尚無符合篩選條件的實績</p>
              <button onClick={() => { setSelectedRole('All'); setSelectedIndustry('All'); setSearchQuery(''); }} className="mt-4 text-[#7c3aed] text-sm font-bold hover:underline">顯示所有案例</button>
            </div>
          )}
        </div>
        
        {filteredCases.length > visibleCount && (
          <div className="mt-16 flex justify-center">
             <button onClick={() => setVisibleCount(v => v + 9)} className="px-16 py-4 bg-[#0f172a] text-white rounded-full font-black text-sm shadow-xl hover:bg-[#1e293b] transition-all active:scale-95">載入更多成功案例 ({filteredCases.length - visibleCount}+)</button>
          </div>
        )}
      </main>

      <LogoMarquee />
      
      {/* 隱藏彈窗元件 */}
      <AIChat isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} cases={cases} onSelectCase={(id) => setSelectedCase(cases.find(c => c.id === id) || null)} onOpenConsultant={() => setIsConsultantOpen(true)} />
      <AIConsultantModal isOpen={isConsultantOpen} onClose={() => setIsConsultantOpen(false)} onContact={() => setIsConsultantOpen(false)} />
      {isUploadOpen && <UploadPortal onClose={() => setIsUploadOpen(false)} onAdd={(c) => {setCases([c, ...cases]); setIsUploadOpen(false); triggerToast('案例發佈成功');}} />}
      
      {isRoadmapOpen && (
        <div className="fixed inset-0 z-[500] bg-white overflow-y-auto">
           <nav className="sticky top-0 bg-white/95 px-12 py-8 border-b border-slate-100 flex items-center justify-between z-50">
              <h2 className="text-2xl font-black tracking-tight">OpenAI 企業導入策略藍圖</h2>
              <button onClick={() => setIsRoadmapOpen(false)} className="p-4 bg-slate-100 rounded-full hover:bg-slate-200 transition-colors"><X className="w-8 h-8 text-slate-600" /></button>
           </nav>
           <div className="max-w-[1440px] mx-auto">
             <ServiceRoadmap />
           </div>
        </div>
      )}

      {selectedCase && (
        <div className="fixed inset-0 z-[400] flex items-center justify-center p-0 md:p-6 bg-slate-950/95 backdrop-blur-2xl animate-in fade-in">
          <div className="bg-white w-full max-w-7xl md:rounded-[40px] overflow-hidden flex flex-col lg:flex-row shadow-3xl relative h-full md:h-auto md:max-h-[92vh]">
            <div className="absolute top-6 right-6 md:top-10 md:right-10 z-50 flex gap-3">
               <button onClick={() => setSelectedCase(null)} className="p-4 bg-white/90 rounded-full shadow-2xl hover:bg-white transition-all"><X className="w-6 h-6 text-slate-600"/></button>
            </div>
            
            <div className="lg:w-[48%] h-[35vh] lg:h-auto shrink-0 relative">
              <img src={selectedCase.imageUrl} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
              <div className="absolute bottom-12 left-12 right-12 space-y-4">
                 <div className="inline-flex px-4 py-1.5 bg-[#7c3aed] text-white text-[11px] font-black rounded-xl mb-3 uppercase tracking-[0.2em]">{selectedCase.role}</div>
                 <h2 className="text-4xl font-black text-white leading-tight tracking-tight">{selectedCase.title}</h2>
                 <p className="text-white/70 text-lg font-bold">{selectedCase.client}</p>
                 <div className="flex gap-6 text-white/50 text-xs font-black uppercase tracking-[0.2em] pt-4 border-t border-white/10"><Calendar className="w-4 h-4" /> {selectedCase.date}</div>
              </div>
            </div>

            <div className="flex-1 p-10 md:p-20 overflow-y-auto bg-white no-scrollbar">
              <div className="space-y-16">
                <section className="space-y-8">
                  <div className="flex items-center gap-3 text-[#7c3aed] font-black text-xs uppercase tracking-[0.3em]"><Zap className="w-6 h-6" /> 戰略性商務影響</div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {(selectedCase.businessImpact || [{ label: '核心成果', value: selectedCase.results }]).map((impact, i) => (
                      <div key={i} className="p-8 bg-slate-50 border border-slate-100 rounded-[32px] group hover:border-[#7c3aed]/40 transition-all hover:bg-white hover:shadow-xl">
                        <p className="text-[11px] uppercase font-black text-slate-400 mb-2 tracking-widest">{impact.label}</p>
                        <p className="text-3xl font-black text-slate-900 group-hover:text-[#7c3aed] transition-colors">{impact.value}</p>
                      </div>
                    ))}
                  </div>
                </section>

                <section className="space-y-8">
                  <h3 className="text-2xl font-black text-slate-900 flex items-center gap-4">
                    <ShieldCheck className="w-8 h-8 text-[#7c3aed]" /> TPI 顧問技術強項
                  </h3>
                  <div className="bg-[#fdfaff] p-10 rounded-[40px] border border-purple-100/50 shadow-inner">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       {[
                         "深度串接 OpenAI 官方 API，確保模型極速響應與穩定性。",
                         "跨系統整合專家，讓 AI 與 Legacy 系統無縫協作。",
                         "資安首選：無幻覺 RAG 框架，確保 99.9% 答案正確率。",
                         "完整技術移轉：提供原始碼與工程團隊實戰賦能培訓。"
                       ].map((strength, i) => (
                         <div key={i} className="flex items-start gap-4">
                            <CheckCircle2 className="w-6 h-6 text-[#7c3aed] mt-1 shrink-0" />
                            <p className="text-base font-bold text-slate-700 leading-relaxed">{strength}</p>
                         </div>
                       ))}
                    </div>
                  </div>
                </section>

                <section className="space-y-8">
                  <h3 className="text-2xl font-black text-slate-900 border-b border-slate-100 pb-5">實施過程與細節</h3>
                  <div className="text-slate-600 leading-relaxed font-bold text-lg bg-slate-50/50 p-10 rounded-[40px] border-2 border-dashed border-slate-100">
                    {selectedCase.detailedContent}
                  </div>
                </section>
                
                <div className="pt-12 pb-10">
                  {!showWhitepaperForm ? (
                    <button 
                      onClick={() => setShowWhitepaperForm(true)}
                      className="w-full py-7 bg-slate-950 text-white rounded-[32px] font-black text-lg flex items-center justify-center gap-4 hover:bg-[#7c3aed] transition-all shadow-2xl active:scale-[0.98]"
                    >
                      索取 AI 轉型戰略白皮書 <ExternalLink className="w-6 h-6" />
                    </button>
                  ) : (
                    <form onSubmit={handleWhitepaperSubmit} className="space-y-6 p-12 bg-slate-50 rounded-[50px] border border-slate-200 animate-in fade-in slide-in-from-bottom-8">
                      <div className="flex items-center gap-5 mb-4">
                        <div className="w-14 h-14 bg-purple-100 rounded-2xl flex items-center justify-center shadow-md"><Mail className="w-7 h-7 text-[#7c3aed]" /></div>
                        <div>
                          <label className="text-xs font-black text-slate-500 uppercase tracking-widest block">專屬企業資源領取</label>
                          <p className="text-base font-bold text-slate-400">輸入企業信箱，我們將發送本案例對應的 2026 戰略指南</p>
                        </div>
                      </div>
                      <div className="flex flex-col md:flex-row gap-4">
                        <input 
                          type="email" 
                          required
                          value={whitepaperEmail}
                          onChange={(e) => setWhitepaperEmail(e.target.value)}
                          placeholder="corporate@tpisoftware.com"
                          className="flex-1 bg-white border-2 border-slate-100 rounded-[24px] px-8 py-6 text-lg font-bold outline-none focus:ring-4 focus:ring-purple-50 focus:border-[#7c3aed] transition-all"
                        />
                        <button 
                          type="submit"
                          className="px-12 py-6 bg-[#7c3aed] text-white rounded-[24px] font-black text-lg hover:bg-purple-700 transition-all shadow-xl active:scale-95 flex items-center justify-center gap-3"
                        >
                          <Send className="w-6 h-6" /> 送出領取
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <button onClick={() => setIsChatOpen(true)} className="fixed bottom-12 right-12 z-[350] w-16 h-16 bg-slate-950 text-white rounded-2xl shadow-3xl flex items-center justify-center hover:scale-110 transition-all active:scale-90 group border border-white/20">
        <Bot className="w-8 h-8 text-[#7c3aed] group-hover:animate-pulse" />
      </button>

      <Footer />
    </div>
  );
};

export default App;
